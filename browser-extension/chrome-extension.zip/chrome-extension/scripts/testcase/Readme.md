# Add test cases to problem statement
This part of extension add test cases to problem statement.

It runs only on the atcoder's problem statement page. Testcases will be downloaded (manually or automatically) and then saved on GitHub. The Js code will load test cases with size smaller than 512 KB then add them to the problem statement.
