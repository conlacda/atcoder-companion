# Mark solved problem

In the task list page, marked the color and add the last submission status for your problems you submitted.
* Green for AC
* Yellow for waiting for judge
* Red for wrong answer
* Some color for TLE, MLE, ...
