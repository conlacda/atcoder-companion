This part helps debug your submissions.
* Copy a test case.
* Download a test case.
* Debug with Atcoder's custom test page
